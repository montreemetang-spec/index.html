-- ============================================================
-- QR Stock POP/POS — Supabase schema
-- รันไฟล์นี้ใน Supabase Dashboard > SQL Editor (รันครั้งเดียวตอนตั้งโปรเจกต์)
-- ============================================================

-- 1) ตารางสินค้า (สต็อกปัจจุบัน)
create table if not exists products (
  code text primary key,
  name text not null,
  unit text,
  brand text,
  channel text,
  price text,
  qty numeric not null default 0,
  updated_at timestamptz not null default now()
);

-- 2) ตารางประวัติการสแกน/เบิก-คืน/เพิ่ม/ตัด (log ทุกเหตุการณ์)
create table if not exists scan_logs (
  id bigint generated always as identity primary key,
  code text not null,
  product_name text,
  action text not null check (action in (
    'เบิก', 'คืน', 'สแกนดูข้อมูล',
    'เพิ่มสินค้าใหม่', 'ชำรุด', 'สูญหาย', 'ตัดจำหน่าย', 'แตก'
  )),
  qty_change numeric default 0,
  qty_after numeric,
  device_name text,
  found boolean default true,
  created_at timestamptz not null default now()
);

-- 3) trigger: อัปเดต updated_at อัตโนมัติเมื่อ qty เปลี่ยน
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_products_updated_at on products;
create trigger trg_products_updated_at
  before update on products
  for each row execute function set_updated_at();

-- 4) เปิด Row Level Security + policy แบบเปิดกว้าง
--    (ใช้งานภายในทีมงานหน้างาน ไม่มี auth ก็อ่าน/เขียนได้ผ่าน anon key)
--    *** ถ้าต้องการความปลอดภัยมากขึ้นในอนาคต ค่อยจำกัด policy ทีหลังได้ ***
alter table products enable row level security;
alter table scan_logs enable row level security;

drop policy if exists "public read products" on products;
create policy "public read products" on products for select using (true);

drop policy if exists "public update products" on products;
create policy "public update products" on products for update using (true) with check (true);

drop policy if exists "public insert products" on products;
create policy "public insert products" on products for insert with check (true);

drop policy if exists "public insert scan_logs" on scan_logs;
create policy "public insert scan_logs" on scan_logs for insert with check (true);

drop policy if exists "public read scan_logs" on scan_logs;
create policy "public read scan_logs" on scan_logs for select using (true);

-- 5) เปิด Realtime สำหรับสองตารางนี้ (ให้ client subscribe แล้วเห็นการเปลี่ยนแปลงสด)
alter publication supabase_realtime add table products;
alter publication supabase_realtime add table scan_logs;

-- ============================================================
-- ขั้นต่อไป: รันไฟล์ seed_products.sql เพื่อใส่ข้อมูลสินค้า 387 รายการ
-- ============================================================
