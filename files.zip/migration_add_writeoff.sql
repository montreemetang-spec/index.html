-- ============================================================
-- Migration: รันไฟล์นี้ถ้าคุณตั้งค่า Supabase ไปแล้วก่อนหน้านี้
-- (ถ้าเพิ่งตั้ง Supabase ใหม่ครั้งแรก ใช้ schema.sql อย่างเดียวพอ ไม่ต้องรันไฟล์นี้)
-- รันใน SQL Editor ครั้งเดียว เพื่ออัปเดตให้รองรับ "เพิ่มสินค้าใหม่" และ "ตัดสินค้า"
-- ============================================================

-- 1) ขยาย action ที่อนุญาตใน scan_logs ให้รองรับเพิ่มสินค้า/ตัดสินค้า
alter table scan_logs drop constraint if exists scan_logs_action_check;
alter table scan_logs add constraint scan_logs_action_check
  check (action in (
    'เบิก', 'คืน', 'สแกนดูข้อมูล',
    'เพิ่มสินค้าใหม่', 'ชำรุด', 'สูญหาย', 'ตัดจำหน่าย', 'แตก'
  ));

-- 2) เพิ่ม policy ให้ insert สินค้าใหม่เข้าตาราง products ได้
--    (ของเดิมมีแค่ select/update ยังไม่มี insert)
drop policy if exists "public insert products" on products;
create policy "public insert products" on products for insert with check (true);

-- เสร็จแล้ว ลองเพิ่มสินค้าใหม่จากแอปดูได้เลย
